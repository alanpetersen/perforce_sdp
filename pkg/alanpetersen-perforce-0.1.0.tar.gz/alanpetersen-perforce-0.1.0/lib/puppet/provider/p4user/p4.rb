Puppet::Type.type(:p4user).provide(:p4) do
  
  def create
  end
  
  def destroy
  end
  
  def exists?
    return true
  end
  
  def instances
  end
end